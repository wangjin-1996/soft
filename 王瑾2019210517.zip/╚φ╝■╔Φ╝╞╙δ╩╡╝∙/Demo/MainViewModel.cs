﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Demo
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        private bool _isEnabled1;
        public bool IsEnabled1
        {
            get { return _isEnabled1; }
            set { _isEnabled1 = value; OnPropertyChanged(); }
        }

        public DelegateCommand OpenWindow =>
            new DelegateCommand(() =>
            {
                new Window1().ShowDialog();
            });

        public static Window1 Window1;

        private bool _isEnabled2;
        public bool IsEnabled2
        {
            get { return _isEnabled2; }
            set { _isEnabled2 = value; OnPropertyChanged(); }
        }

        private string _address;
        public string Address
        {
            get { return _address; }
            set { _address = value; OnPropertyChanged(); CheckEmail(); }
        }

        private void CheckEmail()
        {
            string reg = @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
            Regex r = new Regex(reg);
            IsEnabled1 =  Address != null && r.IsMatch(Address) && Content1 != "" && Image != null && File.Exists(FileName2);
        }

        private string _fileName;
        public string FileName
        {
            get { return _fileName; }
            set { _fileName = value; OnPropertyChanged(); }
        }

        private string _fileName2;
        public string FileName2
        {
            get { return _fileName2; }
            set { _fileName2 = value; OnPropertyChanged(); CheckEmail(); }
        }

        private string _content1;
        public string Content1
        {
            get { return _content1; }
            set { _content1 = value; OnPropertyChanged(); CheckEmail(); }
        }

        private string _content2;
        public string Content2
        {
            get { return _content2; }
            set { _content2 = value; OnPropertyChanged(); IsEnabled2 = Content2 != ""; }
        }

        private BitmapImage _image;
        public BitmapImage Image
        {
            get { return _image; }
            set { _image = value; OnPropertyChanged(); CheckEmail(); }
        }

        public DelegateCommand OpenText =>
            new DelegateCommand(() =>
            {
                var dialog = new OpenFileDialog();
                if (dialog.ShowDialog() != true) return;
                FileName = dialog.FileName;
                Content2 = File.ReadAllText(FileName);
            });

        public DelegateCommand OpenImage =>
            new DelegateCommand(() =>
            {
                var dialog = new OpenFileDialog();
                if (dialog.ShowDialog() != true) return;
                FileName2 = dialog.FileName;
                Image = new BitmapImage(new Uri(FileName2));
            });

        public DelegateCommand Ok =>
            new DelegateCommand(() =>
            {
                Window1.Close();
                Content1 = Content2;
            });

        public DelegateCommand Cancel =>
            new DelegateCommand(() =>
            {
                Window1.Close();
            });
    }
}
